package projektiKNK;


import java.time.LocalDate;
import java.time.chrono.ChronoPeriod;
import java.time.chrono.Chronology;
import java.time.temporal.Temporal;
import java.time.temporal.TemporalField;
import java.time.temporal.TemporalUnit;

import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;

public class AddPacient extends GridPane{

	private TextField FName=new TextField(); 
	private TextField Place=new TextField(); 
	private TextField LName=new TextField();
	private TextField PersonalNr=new TextField();
	private RadioButton Male=new RadioButton("Male");
	private RadioButton Female=new RadioButton("Female");
	private DatePicker  BDay=new DatePicker();
	private Button Clear = new Button("Clear");

	private Button Add = new Button("Add");
	private Button Update = new Button("Update");

	
	private TextField RHFactor=new TextField();
	private TextField BloodType=new TextField();
	private TextField Allergies=new TextField();
	private TextField Vaccination=new TextField();
	private Label GenderLabel = new Label("Gender");
	
	ToggleGroup toggleGroup = new ToggleGroup();

	String cssLayout = 
            "-fx-font-size: 20px;\n" 
			+"-fx-effect: dropshadow(gaussian,lightgrey,2,2,1,1);";
	
	public AddPacient(Pacient p) {
		this();
		FName.setText(p.getFname());
		LName.setText(p.getLname());
		PersonalNr.setText(p.getPersonalnr());
		BDay.setValue(p.getBday());
		RHFactor.setText(p.getRhfactory());
		Allergies.setText(p.getAllergiers());
		Vaccination.setText(p.getVaccinations());
		Update.setVisible(true);
		
	}
	
	public AddPacient()
	{
		setStyle(cssLayout);
		Male.setToggleGroup(toggleGroup);
		Female.setToggleGroup(toggleGroup);
		setVgap(20);
		setHgap(20);
		setAlignment(Pos.CENTER);
		addRow(0,new Label("First Name"),FName,new Label ("Blood Type"),BloodType);
		addRow(1,new Label("Last Name"),LName,new Label ("RH Factor"),RHFactor);
		addRow(2,new Label("Personal Number"),PersonalNr,new Label ("Allergies"),Allergies);
		addRow(3,new Label("Birthday"),BDay,new Label ("Vaccination"),Vaccination);
		addRow(4,new Label("Place"),Place);
		addRow(5, GenderLabel,Male);
		addRow(6, new Label(""),Female,new Label());
		add(Clear,5,5);
		add(Add,5,6);
		Update.setVisible(false);
		add(Update,5,7);
		
		Clear.setOnAction(new AddEventsToButtons());
		Add.setOnAction(e -> {
			if(Validate()) {
			Boolean gender = (toggleGroup.getSelectedToggle().toString().equals("Female")) ? true : false;
			System.out.println(gender);
			Pacient.insertInPacient(FName.getText(), LName.getText(), BDay.getValue(), Place.getText(), gender, RHFactor.getText(), BloodType.getText(), 
					Vaccination.getText(), Allergies.getText(), PersonalNr.getText());
			}
		});
		
	}
	
	
	
	public Button getClear() {
		return this.Clear;
	}
	/*public static void clearFields()
	{
		FName.setText("");
		LName.setText("");
		PersonalNr.setText("");
		BDay.setValue(null);
		RHFactor.setText("");
		Allergies.setText("");
		Vaccination.setText("");
		BloodType.setText("");
		java.sql.Date gettedDatePickerDate = java.sql.Date.valueOf(BDay.getValue());
		System.out.println(gettedDatePickerDate.toString());

	}*/
	/*public static Boolean getGender()
	{
		Boolean ok=true;
		if (gender.toLowerCase().indexOf("female".toLowerCase()) != -1)
		{
			ok=true;
		}
		else
		{
			ok=false;
		}
		return ok;
		
	}*/
	
	public Boolean Validate() {
		Boolean a = true;
		if(FName.getText() == null || FName.getText().equals("")) {
			FName.setStyle("-fx-border-color:red");
			a = false;
		}
		if(LName.getText() == null || LName.getText().equals("")) {
			LName.setStyle("-fx-border-color:red");
			a = false;
		} 
		if(PersonalNr.getText() == null || PersonalNr.getText().equals("")) {
			PersonalNr.setStyle("-fx-border-color:red");
			a = false;
		}
		if(toggleGroup.getSelectedToggle() == null) {
			GenderLabel.setTextFill(Color.RED);
			a = false;
		}
		if(BDay.getValue() == null) {
			BDay.setStyle("-fx-border-color:red");
			a = false;
		}
		if(Place.getText() == null || Place.getText().equals("")) {
			Place.setStyle("-fx-border-color:red");
			a = false;
		}
		
		return a;
	}
	
}
