package projektiKNK;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Screen;
import javafx.stage.Stage;


public class MainProgram  extends Application{

	
	
	public static BorderPane primaryPane;
	public static Stage PrintGuidance=new Stage();
	public static Scene s;
	
	public static void main(String[] args) throws ParseException 
	{
		
		
	new   ConnectToDB();
		java.util.Date d = new SimpleDateFormat("dd/MM/yyyy").parse("08/05/2019");
		//Pacient.insertInTable("1", "1", new Date(d.getYear(),d.getMonth(),d.getDay()), "1", true, "1", "1", "1", "1", "1");
		//Visit.insertInTable(new Date(d.getYear(),d.getMonth(),d.getDay()),"1", "1",  "1");
	
		launch(args);
	}

	
	@Override
	public void start(Stage stage)  
	{
	
		
		ScrollPane slide=new ScrollPane();
		
		Rectangle2D primaryScreenBounds = Screen.getPrimary().getVisualBounds();
		stage.setX(primaryScreenBounds.getMinX());
		stage.setY(primaryScreenBounds.getMinY());
		stage.setWidth(primaryScreenBounds.getWidth());
		stage.setHeight(primaryScreenBounds.getHeight());
		stage.setResizable(false);
		//TableView t=new TableView();
		primaryPane=new BorderPane();
		
		
		//t.setText(ConnectToDB.result.toString());
		primaryPane.setTop(new Menubar());
		primaryPane.setLeft(new LeftSideButtons());
		//primaryPane.setCenter(new ShowVisits());
		primaryPane.setRight(new RightPart());
		primaryPane.setBottom(new BottomPart());
		
		
		/*Stage print =new Stage();
		print.setMinHeight(842);
		print.setMinWidth(595);
		print.setResizable(false);
		print.setScene(s);*/
		
		
		
		//stage.setScene(diti);
		
		s=new Scene(primaryPane);

		//stage.setMinWidth(1000);
		//stage.setMinHeight(1000);
		stage.getIcons().add(new Image("file:///C:/Users/ditjo/eclipse-workspace/OrdinancaMjeksore/src/projektiKNK/ordi2.png"));
		stage.setTitle("Ordinaca Mjeksore");
		stage.setScene(s);
		stage.show();
		primaryPane.requestFocus();
		//print.show();
	}

}
