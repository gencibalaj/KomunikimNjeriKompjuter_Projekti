package projektiKNK;

import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.text.Text;

public class RemovePacient extends ConnectToDB {
	
	
	
	
/*	RemovePacient()
	{

		getColumns().addAll(0,new Text("diti"));
		
		
		
		
		
		
		
		
	} */
	
	
	
}
