package projektiKNK;

import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;

public class UserInfo extends GridPane{
	
	private Label name=new Label("User Name");
	private Label lname=new Label("User Last Name");
	public static Text namefromdb=new Text("Test");
	public static Text lnamefromdb=new Text("Test");
	
	public UserInfo()
	{
		setAlignment(Pos.CENTER);
		
		setVgap(10);
		setHgap(10);
		addRow(0,name,namefromdb);
		addRow(1,lname,lnamefromdb);
		
	}

}
