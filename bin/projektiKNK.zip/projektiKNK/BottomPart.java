package projektiKNK;

import java.time.Clock;
import java.time.Instant;
import java.time.ZoneId;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;

public class BottomPart extends HBox {
	StackPane sp=new StackPane();
	Image image = new Image("file:///C:/Users/ditjo/Desktop/shutdown.png");
	ImageView img=new ImageView();
	Image image1 = new Image("file:///C:/Users/ditjo/Desktop/restar.png");
	ImageView img1=new ImageView();
	public BottomPart()
	{	
		setSpacing(600);
		setStyle("-fx-background-color: #605ca8;");
		sp.setPadding(new Insets(10,10,10,10));
		sp.setPrefWidth(280);
		sp.getChildren().add(new ClockPane());
		setAlignment(Pos.CENTER);
	img.setImage(image);
	img.setFitHeight(200);	
	img.setFitWidth(200);
	
	img1.setImage(image1);
	img1.setFitHeight(200);	
	img1.setFitWidth(200);
	
	getChildren().addAll(img,img1,sp);
	}
	
}
