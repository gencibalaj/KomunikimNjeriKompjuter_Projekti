package projektiKNK;



import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.control.TextArea;

public class PrintGuideline extends VBox {
		
	private Text namefromdb=new Text("test");
	private Text lnamefromdb=new Text("test");
	private Text nrpersonalfromdb=new Text("test");
	private Text docnamefromdb=new Text("test");
	private TextArea descripion=new  TextArea();
	public static StackPane spane;
	HBox h1=new HBox(50);
	HBox h2=new HBox(20);
	HBox h3=new HBox(20);
	HBox h4=new HBox(20);
	HBox h5=new HBox(20);
	HBox h6=new HBox(20);
	HBox h7=new HBox(20);
	HBox h8=new HBox(20);
	Image image = new Image("file:///C:/Users/ditjo/eclipse-workspace/OrdinancaMjeksore/src/projektiKNK/ordi2.png");
	ImageView img=new ImageView();
	public PrintGuideline()
	{
		setPadding(new Insets(10,10,10,10));
		setSpacing(20);
		setMinHeight(842);
		setMinWidth(595);
		h1.setAlignment(Pos.CENTER);
		h2.setAlignment(Pos.TOP_LEFT);
		h3.setAlignment(Pos.TOP_LEFT);
		h4.setAlignment(Pos.TOP_LEFT);
		h5.setAlignment(Pos.TOP_LEFT);
		h6.setAlignment(Pos.CENTER);
		h7.setAlignment(Pos.BOTTOM_RIGHT);
		
	
		img.setImage(image);
	
		
		img.setFitHeight(200);	
		img.setFitWidth(200);
		
		h1.getChildren().addAll(img,new Text("ORDINANCA MJEKSORE"));
		h2.getChildren().addAll(new Label("First Name"),namefromdb);
		h3.getChildren().addAll(new Label("Last Name"),lnamefromdb);
		h4.getChildren().addAll(new Label("Personal Number"),nrpersonalfromdb);
		h5.getChildren().addAll( new Label("Medical Guideliness:"));
		h6.getChildren().addAll(descripion);
		h7.getChildren().addAll( new Label("Releast by:"),docnamefromdb);
		descripion.setPrefHeight(300);
		descripion.setPrefWidth(600); 
		
		
			
		getChildren().addAll(h1,h2,h3,h4,h5,h6,h7);
		
	}
	
	
	
	
	
	
	
}
