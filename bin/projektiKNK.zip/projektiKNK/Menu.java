package projektiKNK;

public class Menu {

}
