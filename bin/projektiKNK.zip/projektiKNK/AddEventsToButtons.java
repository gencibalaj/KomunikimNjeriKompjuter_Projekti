
package projektiKNK;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class AddEventsToButtons extends Button implements  EventHandler<ActionEvent>  {
	
	//ScrollPane scroll=new ScrollPane();
	ScrollPane scroll = new ScrollPane();
	 HBox buttons=new HBox(10);
	  Button Delete=new Button("Delete");
		Button Update=new Button("Update");
		 StackPane pane=new StackPane();
		 VBox buttonplustable=new VBox(10);
		 Scene s=new Scene(pane);
		 TextField search=new TextField();
		 
	public void handle(ActionEvent e) 
	{
		
		buttonplustable.setPadding(new Insets(10,10,10,10));
		pane.getChildren().clear();
		buttons.getChildren().clear();
		buttonplustable.getChildren().clear();
		buttons.getChildren().addAll(Delete,Update,search);
	//	buttons.setAlignment(Pos.CENTER);
		buttonplustable.setAlignment(Pos.CENTER);
		 //scroll.setFitToHeight(true);
		 //scroll.setFitToWidth(true);
		 
		
		 
		switch(((Button)e.getSource()).getText()) {
		
		  case "Add Pacient" :
			  	MainProgram.primaryPane.setCenter(new  AddPacient());
			 
		    break;
		    
		  case "Show Visits":
			  
			  System.out.println("EEEEEEE");
			  
			  MainProgram.primaryPane.setCenter(new ShowVisits());
			
			 break;
		  case "Add Visit":
			  

			  MainProgram.primaryPane.setCenter(new AddVisit());
			
			 
			 
			  
			  
			break;
			
		  case "Print Guidance":
			  
			  pane.getChildren().add(new PrintGuideline());
			
				
				MainProgram.PrintGuidance.setMinHeight(842);
				MainProgram.PrintGuidance.setMinWidth(595);
				MainProgram.PrintGuidance.setResizable(false);
				MainProgram.PrintGuidance.setScene(s);
				MainProgram.PrintGuidance.show();
				 
				
				  break;
				  
				  
				  
		  case"Show Pacients":			
				  MainProgram.primaryPane.setCenter(new ShowPacients());
			  
			 
			  break;
			  
		
		
	}
	
	}
	


}
